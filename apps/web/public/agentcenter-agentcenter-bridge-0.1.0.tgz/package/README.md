# AgentCenter Bridge

OpenClaw plugin that creates a persistent WebSocket connection between your OpenClaw instance and [AgentCenter Cloud](https://agentcenter.cloud), enabling real-time task delivery and agent status reporting.

## Install

```bash
openclaw plugins install clawhub:@agentcenter/agentcenter-bridge
```

## Configure

Add the following to your `~/.openclaw/openclaw.json`:

```json
{
  "plugins": {
    "entries": {
      "agentcenter-bridge": {
        "enabled": true,
        "config": {
          "agentCenterUrl": "wss://your-instance.agentcenter.cloud/live-gateway",
          "token": "<setup-token-from-agentcenter>"
        }
      }
    }
  }
}
```

Then restart OpenClaw. The plugin connects automatically and prints a permanent token on first registration — replace the setup token with that permanent token in your config.

### Config options

| Field | Required | Description |
|---|---|---|
| `agentCenterUrl` | Yes | WebSocket URL of your AgentCenter Cloud live gateway |
| `token` | Yes | Setup token from the AgentCenter Live Gateway wizard |
| `fingerprint` | No | Stable machine ID. Auto-derived from hostname + MAC if omitted |
| `reconnectBaseMs` | No | Reconnect backoff base in ms. Default: `2000` |
| `reconnectMaxMs` | No | Maximum reconnect backoff in ms. Default: `30000` |

---

## Development

### Prerequisites

- Node.js 18+
- npm 9+
- [clawhub CLI](https://clawhub.ai) for publishing

### Build

```bash
npm run build
```

Bundles `src/index.ts` into `dist/index.js` via esbuild.

### Type check

```bash
npm run typecheck
```

### Local pack (for fallback `.tgz` served by the web app)

```bash
npm run pack
```

Builds and outputs `agentcenter-bridge-<version>.tgz` into `apps/web/public/`.

---

## Publishing to ClawHub

### First-time setup (once per machine)

```bash
npm run clawhub:setup
```

Installs the clawhub CLI globally and authenticates with your GitHub account.

### Dry run (preview which files will be included)

```bash
npm run clawhub:dry
```

Builds and runs `npm pack --dry-run` — lists all files that would be bundled without uploading anything.

### Publish current version

```bash
npm run clawhub:publish
```

Runs typecheck + build, then publishes to `agentcenter/agentcenter-bridge` on ClawHub.

### Release a new version

```bash
# Patch release (0.1.0 → 0.1.1) — bug fixes
npm run release:patch

# Minor release (0.1.0 → 0.2.0) — new features, backwards compatible
npm run release:minor

# Major release (0.1.0 → 1.0.0) — breaking changes
npm run release:major
```

Each release command bumps the version in `package.json`, builds, and publishes in one step.

> Version is automatically synced to `openclaw.plugin.json` as part of the release command.

---

## License

MIT — see [LICENSE](./LICENSE)
